import { useState } from "react";

export default function ThemeToggle() {
  const [theme, setTheme] = useState("light");
  const isDark = theme === "dark";

  const pageStyle = {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: isDark
      ? "linear-gradient(135deg, #0f172a, #020617)"
      : "linear-gradient(135deg, #667eea, #764ba2)",
    transition: "all 0.4s ease",
    fontFamily: "Poppins, sans-serif",
    padding: "20px",
  };

  const cardStyle = {
    width: "min(520px, 95vw)",
    borderRadius: "24px",
    padding: "30px",
    textAlign: "center",
    background: isDark
      ? "rgba(15, 23, 42, 0.8)"
      : "rgba(255, 255, 255, 0.85)",
    backdropFilter: "blur(10px)",
    boxShadow: "0 20px 40px rgba(0,0,0,0.3)",
    border: "1px solid rgba(255,255,255,0.2)",
    color: isDark ? "#e5e7eb" : "#111827",
    transition: "all 0.4s ease",
  };

  const buttonStyle = {
    padding: "14px 22px",
    borderRadius: "14px",
    border: "none",
    cursor: "pointer",
    fontWeight: "bold",
    fontSize: "16px",
    marginTop: "15px",
    background: isDark
      ? "linear-gradient(135deg, #22c55e, #06b6d4)"
      : "linear-gradient(135deg, #ff512f, #dd2476)",
    color: "#fff",
    boxShadow: "0 8px 20px rgba(0,0,0,0.4)",
    transition: "transform 0.2s ease",
  };

  const badgeStyle = {
    display: "inline-block",
    padding: "8px 14px",
    borderRadius: "999px",
    fontSize: "14px",
    fontWeight: 700,
    marginLeft: "8px",
    background: isDark
      ? "linear-gradient(135deg, #22c55e, #06b6d4)"
      : "linear-gradient(135deg, #ff512f, #dd2476)",
    color: "#fff",
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ marginTop: 0 }}>🌈 Colorful Theme Toggle</h1>

        <p style={{ lineHeight: 1.6 }}>
          Click the button to switch between Light and Dark mode.
        </p>

        <p>
          Current Theme:
          <span style={badgeStyle}>{theme.toUpperCase()}</span>
        </p>

        <button
          style={buttonStyle}
          onClick={toggleTheme}
          onMouseOver={(e) => (e.target.style.transform = "scale(1.05)")}
          onMouseOut={(e) => (e.target.style.transform = "scale(1)")}
        >
          Switch to {isDark ? "Light" : "Dark"} Mode
        </button>
      </div>
    </div>
  );
}
