import ThemeToggle from "./ThemeToggle";

function App() {
  return <ThemeToggle />;
}

export default App;
