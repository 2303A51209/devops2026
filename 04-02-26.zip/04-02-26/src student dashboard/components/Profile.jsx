function Profile() {
  return (
    <div style={styles.card}>
      <h2 style={{ color: "#059669" }}>Profile</h2>
      <ul>
        <li>Name: Rahul Kumar</li>
        <li>Email: rahul@student.edu</li>
        <li>Department: Computer Science</li>
      </ul>
    </div>
  );
}

const styles = {
  card: {
    background: "linear-gradient(135deg, #dcfce7, #bbf7d0)",
    padding: "25px",
    borderRadius: "12px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
  },
};

export default Profile;
