function Dashboard() {
  return (
    <div style={styles.card}>
      <h2 style={{ color: "#2563eb" }}>Dashboard</h2>
      <p>Overview of student performance.</p>
      <ul>
        <li>Attendance: <span style={styles.green}>92%</span></li>
        <li>Assignments Completed: <span style={styles.orange}>18 / 20</span></li>
        <li>Current GPA: <span style={styles.purple}>8.5</span></li>
      </ul>
    </div>
  );
}

const styles = {
  card: {
    background: "linear-gradient(135deg, #e0f2fe, #bae6fd)",
    padding: "25px",
    borderRadius: "12px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
  },
  green: { color: "#16a34a", fontWeight: "bold" },
  orange: { color: "#ea580c", fontWeight: "bold" },
  purple: { color: "#7c3aed", fontWeight: "bold" },
};

export default Dashboard;
