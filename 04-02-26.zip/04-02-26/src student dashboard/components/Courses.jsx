function Courses() {
  return (
    <div style={styles.card}>
      <h2 style={{ color: "#db2777" }}>Courses</h2>
      <ul style={styles.list}>
        <li>Data Structures</li>
        <li>Web Technologies</li>
        <li>Database Management Systems</li>
        <li>Software Engineering</li>
      </ul>
    </div>
  );
}

const styles = {
  card: {
    background: "linear-gradient(135deg, #fce7f3, #fbcfe8)",
    padding: "25px",
    borderRadius: "12px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
  },
  list: {
    lineHeight: "2",
    fontWeight: "bold",
  },
};

export default Courses;
