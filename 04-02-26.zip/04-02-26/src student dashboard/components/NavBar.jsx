import { NavLink } from "react-router-dom";

function NavBar() {
  return (
    <nav style={styles.nav}>
      <NavLink to="/" style={styles.link}>Dashboard</NavLink>
      <NavLink to="/courses" style={styles.link}>Courses</NavLink>
      <NavLink to="/profile" style={styles.link}>Profile</NavLink>
    </nav>
  );
}

const styles = {
  nav: {
    display: "flex",
    gap: "30px",
    padding: "18px",
    justifyContent: "center",
    background: "linear-gradient(90deg, #6366f1, #ec4899)",
  },
  link: {
    color: "white",
    textDecoration: "none",
    fontWeight: "bold",
    fontSize: "18px",
  },
};

export default NavBar;
